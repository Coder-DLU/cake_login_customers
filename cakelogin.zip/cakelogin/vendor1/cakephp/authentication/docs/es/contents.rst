Contents
########

.. toctree::
    :maxdepth: 2
    :caption: CakePHP Authentication

    /index
    /authenticators
    /authentication-component
