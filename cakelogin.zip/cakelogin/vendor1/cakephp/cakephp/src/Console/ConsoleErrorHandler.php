<?php
declare(strict_types=1);

class_alias(
    'Cake\Error\ConsoleErrorHandler',
    'Cake\Console\ConsoleErrorHandler'
);
deprecationWarning(
    'Use Cake\Error\ConsoleErrorHandler instead of Cake\Console\ConsoleErrorHandler.'
);
